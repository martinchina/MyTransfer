#!/bin/bash

PACKAGE_NAME=A20_DWH_STG
PACKAGE_VERSION=0.0.1

TENANT_CODE=""

### Global Variables ### 
g_Date=$(date  +'%Y%m%d')
g_File=$(readlink -f  $0)
g_Path=$(dirname $g_File)
g_Logg=${g_Path}/log/${g_Date}/${PACKAGE_NAME}_Setup.log

g_Trackfile=${g_Path}/.track_data
g_Bakuplist=${g_Path}/.bakup_list
g_Pids=$$

### Common Functions ### 
function log_message() {
    local   s_msg_time=`date +"%Y-%m-%d %H:%M:%S"`
    echo "[$s_msg_time][pid:$g_Pids] $*" |tee -a $g_Logg
    return 0
}

function log_init() {
    mkdir -p $(dirname $g_Logg)    >/dev/null 2>&1
    touch    $g_Logg               >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        echo "WARNING! Failed to Create Log File [$g_Logg], please check."
        return 1
    fi
    log_message "Log File At: [${g_Logg}]"
    return 0
}

function usage() {
    echo -e "usage:\n\t$0 [TENANT_CODE](Default:dk)"
    echo -e "e.g.  \n\t$0 [dk]"
}

### Local Functions ### 
function get_environment() {
    if [ "x${ETL_ROOT}" == "x" ]; then 
        log_message "ERROR! Environment Var - 'ETL_ROOT'(Deploy Base) Not Found, Define it firstly! RC:1"
        return 1
    fi
    return 0
}

function init_deploy() {
    # export DEPLOY_BASE=${ETL_ROOT}/${TENANT_CODE} # e.g. [/etl/dk]
    export BACKUP_BASE_DIR=${DEPLOY_BASE}/BACKUP
    export CURBAK_BASE_DIR=${BACKUP_BASE_DIR}/${g_Date}_${g_Pids}
    
    mkdir  -p ${CURBAK_BASE_DIR} >/dev/null 2>&1 
    if [ $? -ne 0 ]; then 
        log_message "ERROR! Failed To Create Backup Base Directory: [${CURBAK_BASE_DIR}]. Check User Privileges! RC:1"
        return 1
    fi
    
    # g_Bakuplist=${g_Path}/.track_list
    rm -f ${g_Bakuplist} >/dev/null 2>&1
    touch ${g_Bakuplist} >/dev/null 2>&1
    if [ $? -ne 0 ]; then 
        log_message "ERROR! Failed To Create Track List File: [${g_Bakuplist}]. Check User Privileges! RC:1"
        return 1
    fi
    
    return 0
}

function finish_backup() {
    if [ "x${CURBAK_BASE_DIR}" == "x" ]; then 
        log_message "ERROR! Unknown Backup Base Directory: '${CURBAK_BASE_DIR}'. Call init_deploy() firstly! RC:1"
        return 1
    fi
    
    if [ ! -e ${g_Trackfile} ]; then
        touch ${g_Trackfile} >/dev/null 2>&1
        if [ $? -ne 0 ]; then 
            log_message "ERROR! Failed to create track File: [${g_Trackfile}], Check Write Permissions! RC:1"
            return 1
        fi
        
        # Important for Correct Rollback Automation.
        echo "FIRST_BACKUP_DIR=${CURBAK_BASE_DIR}" > ${g_Trackfile}
        cat ${g_Bakuplist} >> ${g_Trackfile}
        s_file_info=$(ls -rlt ${g_Trackfile}|head -1)
        n_line_info=$(wc -l   ${g_Trackfile})
        log_message "INFO: Track File - [${s_file_info}]."
        log_message "INFO: Total Line - [${n_line_info}]."
    fi
    
    exit 0
}

# _Call: backup_filedirs() ${TARGET_FILES}
function backup_filedirs() {
    if [ "x${CURBAK_BASE_DIR}" == "x" ]; then 
        log_message "ERROR! Unknown Backup Base Directory: '${CURBAK_BASE_DIR}'. Call init_deploy() firstly! RC:1"
        return 1
    fi
    
    input_name="$1"
    target_obj="${DEPLOY_BASE}/${input_name}"
    n_dir_flag=$(file ${target_obj}|grep 'directory'|wc -l)
    if [ $n_dir_flag -eq 1 ]; then
        # Backup directory
        tgz_file=${CURBAK_BASE_DIR}/${input_name}.tar.gz
        tar -czf ${tgz_file} ${target_obj}
        if [ $? -ne 0 ]; then
            log_message "ERROR! Failed to create archive: 'tar -czf ${tgz_file} ${target_obj}'. Check Write Permissions! RC:1"
            return 1
        fi
        
        ## Logging Format: 
        #       'BAKUP_TRACK:${TYPE}:Backup_Archive_XXX.tar.gz=${input_name}]
        ## Restore Format: 
        #       rm  -rf  ${DEPLOY_BASE}/${input_name}
        #       tar -xzf Backup_Archive_XXX.tar.gz -C ${DEPLOY_BASE}/
        echo    "BAKUP_TRACK:DIR:${tgz_file}=${input_name}" >> ${g_Bakuplist}
        log_message "INFO: Backup directory ${target_obj} to ${tgz_file} Success."
    else
        # Backup ux-file
        tgz_file=${CURBAK_BASE_DIR}/${input_name}.tar.gz
        tar -czf ${tgz_file} ${target_obj}
        if [ $? -ne 0 ]; then
            log_message "ERROR! Failed to create backup archive: 'tar -czf ${tgz_file} ${target_obj}'. Check Write Permissions! RC:1"
            return 1
        fi
        
        ## Logging Format: 
        #       'BAKUP_TRACK:${TYPE}:Backup_Archive_XXX.tar.gz=${input_name}]
        ## Restore Format: 
        #       rm  -rf  ${DEPLOY_BASE}/${input_name}
        #       tar -xzf Backup_Archive_XXX.tar.gz ${DEPLOY_BASE}/${input_name}
        echo    "BAKUP_TRACK:FILE:${tgz_file}=${input_name}" >> ${g_Bakuplist}
        log_message "INFO: Backup file ${target_obj} to ${tgz_file} Success."
    fi
    
    return 0
}

# _Call: deploy_filedirs()  ${TARGET_FILES}
function deploy_filedirs()  {
    # deploy_filedirs config
    input_name="$1"
    
    # Source: ${g_Path}/${input_name}
    # Target: ${DEPLOY_BASE}/${input_name}
    deploy_source="${g_Path}/${input_name}"
    deploy_target="${DEPLOY_BASE}/${input_name}"
    
    log_message "INFO: Deploy writing file & dirs [${deploy_source}] => [${deploy_target}] .."
    cp -rpf ${deploy_source} ${deploy_target}
    if [ $? -ne 0 ]; then
        log_message "ERROR! Failed to write to target: 'cp -rpf ${deploy_source} ${deploy_target}'. Check Write Permissions! RC:1"
        return 1
    fi
    log_message "INFO: Success."
    return 0
}

# _Call: deploy_commonsettings()
function deploy_commonsettings() {
    chmod 755 ${DEPLOY_BASE}/shell/*.sh      >/dev/null 2>&1
    chmod 644 ${DEPLOY_BASE}/shell/lib/*.jar >/dev/null 2>&1
    chmod 644 ${DEPLOY_BASE}/config/*.*      >/dev/null 2>&1
    return 0
}

# _Call: record_fileinfo() ${TARGET_FILE}
#   e.g. record_fileinfo shell/lib/EDWDownloadAndValidate.jar
function record_fileinfo() {
    target_file="${DEPLOY_BASE}/$1"
    s_file_info=$(ls -rlt ${target_file}|head -1)
    log_message "INFO: ${s_file_info}"
    return 0
}

# update_versioninfo() 
function update_versioninfo() {
    # update version info into ${ETL_ROOT}/config/version.conf
    version_file=${ETL_ROOT}/config/version.conf
    
    if [ ! -e ${version_file} ]; then 
        touch ${version_file} 2>&1
        if [ $? -ne 0 ]; then
            log_message "ERROR! Failed to write to target: '${version_file}'. Check Write Permissions! RC:1"
            return 1
        fi
        
        echo  "[Versions]"                            >> ${version_file}
        echo  "[${PACKAGE_NAME}=${PACKAGE_VERSION}]"  >> ${version_file}
        chmod 644 ${version_file} 2>&1
        
        return 0
    fi
    
    n_flag=$(grep "${PACKAGE_NAME}" ${version_file}|grep -v '#'|wc -l)
    if [ $n_flag -le 0 ]; then
        echo  "[${PACKAGE_NAME}=${PACKAGE_VERSION}]"  >> ${version_file}
        if [ $? -ne 0 ]; then
            log_message "ERROR! Failed to modify file: '${version_file}'. Check Write Permissions! RC:1"
            return 1
        fi
    else 
        OLD_VERSION=$(grep "${PACKAGE_NAME}" ${version_file}|grep -v '#'|cut -d'=' -f2)
        sed -i "s#${PACKAGE_NAME}=${OLD_VERSION}#${PACKAGE_NAME}=${PACKAGE_VERSION}#g" ${version_file}
        if [ $? -ne 0 ]; then
            log_message "ERROR! Failed to modify file: '${version_file}'. Check Write Permissions! RC:1"
            return 1
        fi
    fi
    
    chmod 644 ${version_file} 2>&1
    return 0
}

### MAIN ENTRY ### 
log_init
if [ $? -ne 0 ]; then
    echo "ERROR!! Failed to Init Log."
    exit 1
fi
log_message "$0: Started with Parameters [$@] .."

TENANT_CODE=$(echo "$1"|tr "A-Z" "a-z")
if [ "x${TENANT_CODE}" == "x" ]; then 
    TENANT_CODE=dk
    log_message "Using Default TENANT_CODE:dk"
fi

log_message "Deploy Package Name  : '${PACKAGE_NAME}'"
log_message "Deploy Package Verion: '${PACKAGE_VERSION}'"

log_message ">> Checking Environment Settings .."
get_environment && { echo "Failed To Call get_environment(). Please Check&Fix Error. "; exit 1; }

export DEPLOY_BASE=${ETL_ROOT}/${TENANT_CODE}       # e.g. [/etl/dk]
log_message "Deploy Base Directory: [${DEPLOY_BASE}]"
cd           ${g_Path}
log_message "Deploy Work Directory: [$(pwd)]"

log_message ">> Init Deploy .."
init_deploy             && { echo "Failed To Call: init_deploy(), Please Check&Fix Error. "  ; exit 1; }

log_message ">> Backup Target Files and Settings .."
backup_filedirs config  && { echo "Failed To Call: backup_filedirs() config , Please Check&Fix Error. "; exit 1; }
backup_filedirs shell   && { echo "Failed To Call: backup_filedirs() shell  , Please Check&Fix Error. "; exit 1; }
finish_backup           && { echo "Failed To Call: finish_backup(), Please Check&Fix Error. "; exit 1; }

log_message ">> Deploy Writing New Files .."
deploy_filedirs config  && { echo "Failed To Call: deploy_filedirs() config , Please Check&Fix Error. "; exit 1; }
deploy_filedirs shell   && { echo "Failed To Call: deploy_filedirs() shell  , Please Check&Fix Error. "; exit 1; }

log_message ">> Deploy Modifying Settings .."
deploy_commonsettings   && { echo "Failed To Call: deploy_commonsettings() , Please Check&Fix Error. " ; exit 1; }

log_message ">> Deploy Key Files Checking & Recording .."
record_fileinfo shell/lib/EDWDownloadAndValidate.jar
record_fileinfo config/config.properties

log_message ">> Deploy Update Version Info .."
update_versioninfo      && { echo "Failed To Call: update_versioninfo() , Please Check&Fix Error. " ; exit 1; }

### <Post.Steps>. Service Operation && Testing..
log_message "$0: All Steps Done Successfully. RC:0"
exit 0
