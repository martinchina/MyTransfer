while getopts u:v: option
do
  case "${option}" in
      u)
         export SID=${OPTARG};;
      v)
         export TID=${OPTARG};;
      ?)
          echo "Usage: args [-u n] [-v n]"
          exit 1;;
  esac
done

export PID=$$
export traceLogDir=${AGENTDIR}/log/applog

#Send Warning Signal in runtime
function traceLog()
{
  Status=$1
  MSG=$2
  traceLogName=${traceLogDir}/APP_${TID}_${SID}_`date +%s`_$RANDOM.log
  echo "${SID}.${TID}.${Status}" >>${traceLogName}.tmp
  echo "[PID:${PID}][DATE:$(date +'%Y-%m-%d')][TIME:$(date +'%H:%M:%S')]" >>${traceLogName}.tmp
  echo "${MSG}" >>${traceLogName}.tmp
  mv ${traceLogName}.tmp ${traceLogName}
}

#Send formated message to stdout via parameter or pipe
function traceError()
{
  MSG="$@"
  if [ ! -z "${MSG}" ]; then
    echo -e "${MSG:0:9600}"|sed 's/$/<br\/>/g'|tr -d '\n'
  else
    head -c9600|sed 's/$/<br\/>/g'|tr -d '\n'
  fi
}

#Collect DS Error Messages to stderr
function traceDSLog()
{
  logName=$1
  level=$2
  if [ "${level}" = "WARNING" ]; then
    LOGLevel="FATAL|WARNING"
  else
    LOGLevel="FATAL"
  fi
  [ ! -f "${logName}" ] && {
    echo "Log file ["${logName}"] not found" >/dev/stderr
    return 2
  }
  fileSize=$(stat -c %s "${logName}")
  [ "${fileSize}" -ge 2000000 ] && {
    echo "Log file ["${logName}"] too large" >/dev/stderr
    return 3
  }
  grep -Poz "(Event(.*\n){2}Type.*(${LOGLevel})\n(.*\n){2}(\s+.*\n)+|.*PROJECT.*|.*/dsjob.*\n)" "${logName}" | grep -Pv '^(Type|User)' | sed 's/$/<br\/>/g' | tr -d '\n' | sed 's/\(Failed to execute.\{200\}\).*\?Reason: /\1... Reason: /' | traceError>/dev/stderr
}
