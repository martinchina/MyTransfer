processLog=${mainDir}/log/process$(date +"%Y%m%d").log
script=`echo $0|sed 's/\.\///g'`
args=`echo "$@"|tr -s ' '`
echo "${args}"|grep '\-u.*\-v'>/dev/null && args=`echo "${args}"|cut -d" " -f5- `
psList=`ps -ef|tr -s ' '|grep "${script}.*${args}$"|grep -v grep|grep -v tclsh`
psCount=`echo "${psList}"|wc -l`
if [ "${psCount}" -gt 2 ]; then
  echo "WARN: $(date +'%Y-%m-%d %H:%M:%S') The process cannot run in parallel! [${script} ${args}]" |tee -a ${processLog}
  echo "${psList}" |tee -a ${processLog}
  exit 99
fi
