shellDir=$(dirname $(readlink -f $0))
configUpDir=${shellDir%/*}

export CLASSPATH=$CLASSPATH:$configUpDir

for jarFile in $(ls $configUpDir/shell/lib/*.jar|grep -v EDW.*.jar)
do
  export CLASSPATH=$CLASSPATH:${jarFile}
done

export CLASSPATH=$CLASSPATH:${configUpDir}/shell/lib/EDWCommonUtil.jar

Decrypt()
{
  for para in $@
  do
    paraValue=${!para}

    if [ "${#paraValue}" -ge 12 -a "${paraValue:0-1:1}" = "=" ]; then
      clearValue=$(java com.asiainfo.commonutil.EncryptUtil -D "${paraValue}" 2>/dev/null)
      if [ "${clearValue}" = "" ]; then
         eval $para=${paraValue}
      else
         eval $para='${clearValue}'
      fi
    fi
  done
}
