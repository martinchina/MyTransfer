function parseDate()
{
  if ! echo "$@"|grep -Px '^\d{8}($|\.\w(\d+-\d+|\d|,)*$)'>/dev/null ;then
    echo "ERROR: require more parameters or format incorrect"
    return 99
  fi

  busiDateRule=$1

  if [[ ${busiDateRule} =~ ".M" ]]; then
    rule=$(echo $busiDateRule|cut -d'.' -f2|sed 's/M//g')
    busiDate=$(echo $busiDateRule|cut -d'.' -f1)
    dates=($(echo $rule|cut -d',' --output-delimiter=" " -f1-))

    if [ ! $(date -d "${busiDate}" "+%Y%m%d" 2>/dev/null) ]; then
      echo "${busiDate}"
      return 99
    fi

    for ((i=0;i<${#dates[@]};i++)); do
      if [[ ${dates[$i]} =~ "-" ]]; then
         if [ "${busiDate:6:2}" -ge "$(echo ${dates[$i]}|cut -d'-' -f1)" -a "${busiDate:6:2}" -le "$(echo ${dates[$i]}|cut -d'-' -f2)" ]; then
           tmp=$(date -d "$(echo $busiDate|cut -d'.' -f1) +1 day" "+%Y%m%d")
           echo $(date -d "${tmp} -1 month" "+%Y%m")
           return 0 
         fi
      elif [ ! -z "${dates[$i]}" ]; then
        if [[ "${dates[$i]}" = "${busiDate:6:2}" ]]; then
           tmp=$(date -d "$(echo $busiDate|cut -d'.' -f1) +1 day" "+%Y%m%d") 
           echo $(date -d "${tmp} -1 month" "+%Y%m")
           return 0
        fi
      else
        continue
      fi
    done
    echo ${busiDate}
    return 1
  elif [[ ${busiDateRule} =~ ".C" ]]; then
    busiDate=$(echo $busiDateRule|cut -d'.' -f1)
    if [ $(date -d "${busiDate}" "+%Y%m%d" 2>/dev/null) ]; then
      echo $(date -d "${busiDate} +1 day" "+%Y%m%d")
      return 0
    else
      echo "Un-expected parameter $busiDate"
      return 99
    fi
  ##monthly report
  elif [[ ${busiDateRule} =~ ".R" ]]; then
    busiDate=$(echo $busiDateRule|cut -d'.' -f1)
    if [ "$(date -d "${busiDate} +1 day" "+%d" 2>/dev/null)" = "01" ]; then
      echo $(date -d "${busiDate}" "+%Y%m")
      return 0
    else
      return 1
    fi
  ##working day,if it is 4th working day, return the last day of the last month
  elif [[ ${busiDateRule} =~ ".W" ]]; then
    busiDate=$(echo $busiDateRule|cut -d'.' -f1)
    case $(date -d"${busiDate::6}01" +%w) in
    0)
      [ ${busiDate} -eq $(date -d"${busiDate::6}01 +4 day" +"%Y%m%d") ] && { echo $(date -d"${busiDate::6}01 -1 day" +"%Y%m%d");return 0; } || return 1
    ;;
    1)
      [ ${busiDate} -eq $(date -d"${busiDate::6}01 +3 day" +"%Y%m%d") ] && { echo $(date -d"${busiDate::6}01 -1 day" +"%Y%m%d");return 0; } || return 1
    ;;
    2)
      [ ${busiDate} -eq $(date -d"${busiDate::6}01 +3 day" +"%Y%m%d") ] && { echo $(date -d"${busiDate::6}01 -1 day" +"%Y%m%d");return 0; } || return 1
    ;;
    3)
      [ ${busiDate} -eq $(date -d"${busiDate::6}01 +5 day" +"%Y%m%d") ] && { echo $(date -d"${busiDate::6}01 -1 day" +"%Y%m%d");return 0; } || return 1
    ;;
    4)
      [ ${busiDate} -eq $(date -d"${busiDate::6}01 +5 day" +"%Y%m%d") ] && { echo $(date -d"${busiDate::6}01 -1 day" +"%Y%m%d");return 0; } || return 1
    ;;
    5)
      [ ${busiDate} -eq $(date -d"${busiDate::6}01 +5 day" +"%Y%m%d") ] && { echo $(date -d"${busiDate::6}01 -1 day" +"%Y%m%d");return 0; } || return 1
    ;;
    6)
      [ ${busiDate} -eq $(date -d"${busiDate::6}01 +5 day" +"%Y%m%d") ] && { echo $(date -d"${busiDate::6}01 -1 day" +"%Y%m%d");return 0; } || return 1
    ;;
    esac
  elif [ $(date -d "${busiDateRule}" "+%Y%m%d" 2>/dev/null) ]; then
    echo $busiDateRule
    return 0
  else
    echo "Un-expected parameter $busiDateRule"
    return 99
  fi
}
