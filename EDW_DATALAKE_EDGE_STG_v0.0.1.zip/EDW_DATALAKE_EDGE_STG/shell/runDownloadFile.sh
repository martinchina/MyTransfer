#!/bin/bash

shellDir=$(dirname $(readlink -f $0))
mainDir=${shellDir%/*}

. ${mainDir}/shell/checkPID.sh
. ${mainDir}/shell/configEnv.sh
. ${mainDir}/shell/LOG.sh
. ${mainDir}/shell/parseDate.sh

#skip schedule server parameter -u -v
[ "$1" = "-u" ] && shift 2
[ "$1" = "-v" ] && shift 2

export CLASSPATH=$CLASSPATH:${mainDir}/shell/lib/EDWDownloadAndValidate.jar

busiDate=$1
subSystem=$2
deadline=$3
flag=$4

busiDate=$(parseDate $busiDate)
result=$?

if [ $result -eq 99 ]; then
  echo "$(date +'%Y-%m-%d %H:%M:%S') ERROR: Business date($busiDate) that you entered is incorrect." >/dev/stderr
  exit 21
elif [ $result -eq 1 ]; then
  echo "$(date +'%Y-%m-%d %H:%M:%S') INFO: The business date($busiDate) is not in the scope."
  exit 0
else
  echo "$(date +'%Y-%m-%d %H:%M:%S') INFO: Start"
fi

if [ "${subSystem}" = "Billing" ];then
  while [ true ]
  do
    if [ $(ps -ef |grep runDownloadCDR|grep ${busiDate}|wc -l 2>/dev/null) -eq 0 ];then
      java com.asiainfo.downloadfile.DownloadMain $busiDate $subSystem $deadline
      exit $?
    else
      sleep 180
    fi
  done
else
  java com.asiainfo.downloadfile.DownloadMain $busiDate $subSystem $deadline
fi

exit $?
