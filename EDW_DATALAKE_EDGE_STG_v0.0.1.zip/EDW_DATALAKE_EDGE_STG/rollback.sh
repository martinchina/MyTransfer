#!/bin/bash

PACKAGE_NAME=A20_DWH_STG
PACKAGE_VERSION=0.0.1

TENANT_CODE=""

### Global Variables ### 
g_Date=$(date  +'%Y%m%d')
g_File=$(readlink -f  $0)
g_Path=$(dirname $g_File)
g_Logg=${g_Path}/log/${g_Date}/${PACKAGE_NAME}_Setup.log

g_Trackfile=${g_Path}/.track_data
g_Rstorlist=${g_Path}/.rstor_list
g_Pids=$$

### Common Functions ### 
function log_message() {
    local   s_msg_time=`date +"%Y-%m-%d %H:%M:%S"`
    echo "[$s_msg_time][pid:$g_Pids] $*" |tee -a $g_Logg
    return 0
}

function log_init() {
    mkdir -p $(dirname $g_Logg)    >/dev/null 2>&1
    touch    $g_Logg               >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        echo "WARNING! Failed to Create Log File [$g_Logg], please check."
        return 1
    fi
    log_message "Log File At: [${g_Logg}]"
    return 0
}

function usage() {
    echo -e "usage:\n\t$0 [TENANT_CODE](Default:dk)"
    echo -e "e.g.  \n\t$0 [dk]"
}

### Local Functions ### 
function get_environment() {
    if [ "x${ETL_ROOT}" == "x" ]; then 
        log_message "ERROR! Environment Var - 'ETL_ROOT'(Deploy Base) Not Found, Define it firstly! RC:1"
        return 1
    fi
    return 0
}

function init_rollback() {
    # export DEPLOY_BASE=${ETL_ROOT}/${TENANT_CODE} # e.g. [/etl/dk]
    export BACKUP_BASE_DIR=${DEPLOY_BASE}/BACKUP
    
    # Find Last Successfully Backup Directory ..
    # g_Trackfile=${g_Path}/.track_data
    if [ ! -e ${g_Trackfile} ]; then 
        log_message "ERROR! Unable to find deploy track file: [${g_Trackfile}], unable to proceed! RC:1"
        return 1
    fi
    
    # export CURBAK_BASE_DIR=${BACKUP_BASE_DIR}/${g_Date}_${g_Pids}
    export FIRST_BACKUP_DIR=$(grep 'FIRST_BACKUP_DIR' ${g_Trackfile}|cut -d'=' -f2|head -1)
    log_message "INFO: Using backup content from first backup directory: [${FIRST_BACKUP_DIR}]"
    
    # g_Rstorlist
    grep 'BAKUP_TRACK' ${g_Trackfile} |grep -v '#' > ${g_Rstorlist}
    if [ ! -e ${g_Rstorlist} ]; then 
        log_message "ERROR! Unable to generate restore list: [${g_Rstorlist}], unable to proceed! RC:1"
        return 1
    fi
    
    export TRASH_BASE_DIR=${BACKUP_BASE_DIR}/_Rollback_Trash
    rm     -rf ${TRASH_BASE_DIR} >/dev/null 2>&1 
    mkdir  -p  ${TRASH_BASE_DIR} >/dev/null 2>&1 
    
    return 0
}

# _Call: remove_filedirs() ${TARGET_FILES}
function remove_filedirs() {
    if [ "x${TRASH_BASE_DIR}" == "x" ]; then 
        log_message "ERROR! Unknown Trash Directory: '${TRASH_BASE_DIR}'. Call init_rollback() firstly! RC:1"
        return 1
    fi
    
    input_name="$1"
    target_obj="${DEPLOY_BASE}/${input_name}"
    
    log_message "INFO: Moving directory ${target_obj} to _trash folder .."
    mv ${target_obj} ${TRASH_BASE_DIR}
    if [ $? -ne 0 ]; then
        log_message "ERROR! Failed to move: 'mv ${target_obj} ${TRASH_BASE_DIR}'. Check Write Permissions! RC:1"
        return 1
    fi
    log_message "INFO: Success."
    return 0
}

# _Call: deploy_filedirs()  ${TARGET_FILES}
function restore_filedirs()  {
    if [ "x${FIRST_BACKUP_DIR}" == "x" ]; then 
        log_message "ERROR! Unknown Trash Directory: '${FIRST_BACKUP_DIR}'. Call init_rollback() firstly! RC:1"
        return 1
    fi
    
    n_total_lines=$(wc -l ${g_Rstorlist})
    log_message "INFO: Total ${n_total_lines} to restore .."
    
    while read LINE
    do
        rstore_recr_typ=$(echo "$LINE"|cut -d':' -f2)
        rstore_tgz_file=$(echo "$LINE"|cut -d':' -f3|cut -d'=' -f1)
        rstore_input_nm=$(echo "$LINE"|cut -d':' -f3|cut -d'=' -f2)
        
        if [ ! -e ${rstore_tgz_file} ]; then 
            log_message "ERROR! Backup file: ${rstore_tgz_file} lost, restore failed!"
            return 1
        fi
        
        log_message "INFO: Restoring ${rstore_recr_typ}:${rstore_input_nm} from Backup file: ${rstore_tgz_file} .."
        if [ "DIR" == "${rstore_recr_typ}" ]; then 
            tar -xzf ${rstore_tgz_file} -C ${DEPLOY_BASE}/ >/dev/null 2>&1
            n_chk_dir=$(file "${DEPLOY_BASE}/${rstore_input_nm}" |grep 'directory' |wc -l)
            if [ $n_chk_dir -eq 1 ]; then
                log_message "INFO: Success."
            else    
                log_message "WARNING: Un-expected restore: [${LINE}]."
            fi
            
            # ## Logging Format: 
            # #       'BAKUP_TRACK:${TYPE}:Backup_Archive_XXX.tar.gz=${input_name}]
            # ## Restore Format: 
            # #       rm  -rf  ${DEPLOY_BASE}/${input_name}
            # #       tar -xzf Backup_Archive_XXX.tar.gz -C ${DEPLOY_BASE}/
            # echo    "BAKUP_TRACK:DIR:${tgz_file}=${input_name}" >> ${g_Bakuplist}
            # log_message "INFO: Backup directory ${target_obj} to ${tgz_file} Success."
            
        elif [ "FILE" == "${rstore_recr_typ}" ]; then
            tar -xzf ${rstore_tgz_file} ${DEPLOY_BASE}/${rstore_input_nm} >/dev/null 2>&1
            if [ -e "${DEPLOY_BASE}/${rstore_input_nm}" ]; then 
                log_message "INFO: Success."
            else    
                log_message "WARNING: Un-expected restore: [${LINE}]."
            fi
            
            # ## Logging Format: 
            # #       'BAKUP_TRACK:${TYPE}:Backup_Archive_XXX.tar.gz=${input_name}]
            # ## Restore Format: 
            # #       rm  -rf  ${DEPLOY_BASE}/${input_name}
            # #       tar -xzf Backup_Archive_XXX.tar.gz ${DEPLOY_BASE}/${input_name}
            # echo    "BAKUP_TRACK:FILE:${tgz_file}=${input_name}" >> ${g_Bakuplist}
            # log_message "INFO: Backup file ${target_obj} to ${tgz_file} Success."
        else  
            log_message "WARNING: Unrecognized restore type: [${LINE}]. (IGNORED)"
        fi
    done < ${g_Rstorlist}
    
    return 0
}

# _Call: deploy_commonsettings()
function deploy_commonsettings() {
    chmod 755 ${DEPLOY_BASE}/shell/*.sh      >/dev/null 2>&1
    chmod 644 ${DEPLOY_BASE}/shell/lib/*.jar >/dev/null 2>&1
    chmod 644 ${DEPLOY_BASE}/config/*.*      >/dev/null 2>&1
    return 0
}

# _Call: record_fileinfo() ${TARGET_FILE}
#   e.g. record_fileinfo shell/lib/EDWDownloadAndValidate.jar
function record_fileinfo() {
    target_file="${DEPLOY_BASE}/$1"
    s_file_info=$(ls -rlt ${target_file}|head -1)
    log_message "INFO: ${s_file_info}"
    return 0
}
 
function print_versioninfo() {
    # update version info into ${ETL_ROOT}/config/version.conf
    version_file=${ETL_ROOT}/config/version.conf
    
    if [ ! -e ${version_file} ]; then 
        log_message "WARNING! No version file: '${version_file}' found. RC:0"
        return 0
    fi
    
    PKG_VERSION=$(grep "${PACKAGE_NAME}" ${version_file}|grep -v '#'|cut -d'=' -f2)
    log_message "INFO: Version of '${PACKAGE_NAME}': '${PKG_VERSION}'"
    return 0
}

### MAIN ENTRY ### 
log_init
if [ $? -ne 0 ]; then
    echo "ERROR!! Failed to Init Log."
    exit 1
fi
log_message "$0: Entered with Parameters [$@] .."

TENANT_CODE=$(echo "$1"|tr "A-Z" "a-z")
if [ "x${TENANT_CODE}" == "x" ]; then 
    TENANT_CODE=dk
    log_message "Using Default TENANT_CODE:dk"
fi

log_message "Rollback Package Name  : '${PACKAGE_NAME}'"
log_message "Rollback Package Verion: '${PACKAGE_VERSION}'"

log_message ">> Checking Environment Settings .."
get_environment && { echo "Failed To Call get_environment(). Please Check&Fix Error. "; exit 1; }

export DEPLOY_BASE=${ETL_ROOT}/${TENANT_CODE}       # e.g. [/etl/dk]
log_message "Deploy Base Directory: [${DEPLOY_BASE}]"
cd           ${g_Path}
log_message "Deploy Work Directory: [$(pwd)]"

log_message ">> Init Rollback .."
init_rollback           && { echo "Failed To Call: init_rollback(), Please Check&Fix Error. "  ; exit 1; }

log_message ">> Rollback: Remove Deployed Files .."
remove_filedirs  config  && { echo "Failed To Call: remove_filedirs() config , Please Check&Fix Error. "; exit 1; }
remove_filedirs  shell   && { echo "Failed To Call: remove_filedirs() shell  , Please Check&Fix Error. "; exit 1; }

log_message ">> Rollback: Backup Target Files and Settings .."
restore_filedirs         && { echo "Failed To Call: restore_filedirs(), Please Check&Fix Error. "; exit 1; }

log_message ">> Rollback: Key Files Checking & Recording .."
record_fileinfo shell/lib/EDWDownloadAndValidate.jar
record_fileinfo config/config.properties

print_versioninfo

### <Post.Steps>. Service Operation && Testing..
log_message "$0: All Steps Done Successfully. RC:0"
exit 0
